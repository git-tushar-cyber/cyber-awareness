"use client";

import { useState, useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { motion } from "framer-motion";

// Fix for Leaflet marker icons in Next.js
const fixLeafletMarker = () => {
  // Only fix in browser environment
  if (typeof window !== "undefined") {
    // @ts-ignore
    delete L.Icon.Default.prototype._getIconUrl;

    L.Icon.Default.mergeOptions({
      iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
      iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
      shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
    });
  }
};

// Attack Coordinates - Major cities around the world
const attackSources = [
  { name: "New York", lat: 40.7128, lng: -74.0060 },
  { name: "London", lat: 51.5074, lng: -0.1278 },
  { name: "Tokyo", lat: 35.6762, lng: 139.6503 },
  { name: "Beijing", lat: 39.9042, lng: 116.4074 },
  { name: "Moscow", lat: 55.7558, lng: 37.6173 },
  { name: "Mumbai", lat: 19.0760, lng: 72.8777 },
  { name: "São Paulo", lat: 23.5558, lng: -46.6396 },
  { name: "Sydney", lat: -33.8688, lng: 151.2093 },
  { name: "Berlin", lat: 52.5200, lng: 13.4050 },
  { name: "Johannesburg", lat: -26.2041, lng: 28.0473 },
];

// Attack Destinations - Data centers and major tech hubs
const attackTargets = [
  { name: "AWS US-East", lat: 39.0438, lng: -77.4874 },
  { name: "Google Cloud EU", lat: 50.1109, lng: 8.6821 },
  { name: "Azure Asia", lat: 1.3521, lng: 103.8198 },
  { name: "Amazon EU", lat: 53.3498, lng: -6.2603 },
  { name: "Financial District", lat: 40.7128, lng: -74.0060 },
  { name: "Tech Hub", lat: 37.7749, lng: -122.4194 },
  { name: "Government Center", lat: 38.9072, lng: -77.0369 },
];

// Attack types with corresponding circle colors
const attackTypes = [
  { type: "Phishing", color: "red" },
  { type: "Malware", color: "orange" },
  { type: "DDoS", color: "green" },
  { type: "Ransomware", color: "yellow" },
  { type: "Data Breach", color: "blue" },
];

// Attack animation component
const AttackLine = ({ start, end, onComplete }) => {
  const svgRef = useRef(null);
  const [progress, setProgress] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Animate the attack line
    const duration = Math.random() * 1000 + 2000; // 2-3 second animation
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min(elapsed / duration, 1);
      setProgress(newProgress);

      if (newProgress < 1) {
        requestAnimationFrame(animate);
      } else {
        setTimeout(() => {
          setIsVisible(false);
          onComplete();
        }, 200);
      }
    };

    requestAnimationFrame(animate);
  }, [onComplete]);

  if (!isVisible) return null;

  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        zIndex: 999,
        overflow: "hidden",
      }}
    >
      <svg ref={svgRef} width="100%" height="100%" style={{ position: "absolute", top: 0, left: 0 }}>
        <line
          x1={start.x}
          y1={start.y}
          x2={start.x + (end.x - start.x) * progress}
          y2={start.y + (end.y - start.y) * progress}
          stroke={attackTypes[Math.floor(Math.random() * attackTypes.length)].color}
          strokeWidth="2"
          strokeDasharray="5,5"
          opacity="0.7"
        />
        <circle
          cx={start.x + (end.x - start.x) * progress}
          cy={start.y + (end.y - start.y) * progress}
          r="3"
          fill={attackTypes[Math.floor(Math.random() * attackTypes.length)].color}
          opacity="0.9"
        />
      </svg>
    </div>
  );
};

export default function CyberMap() {
  const [attacks, setAttacks] = useState([]);
  const [attackId, setAttackId] = useState(0);
  const mapRef = useRef(null);

  // Fix Leaflet marker icon issue
  useEffect(() => {
    fixLeafletMarker();
  }, []);

  // Add random attacks periodically
  useEffect(() => {
    const addAttack = () => {
      if (!mapRef.current) return;

      const sourceIndex = Math.floor(Math.random() * attackSources.length);
      const targetIndex = Math.floor(Math.random() * attackTargets.length);

      const source = attackSources[sourceIndex];
      const target = attackTargets[targetIndex];

      // Convert lat/lng to pixel coordinates
      const map = mapRef.current;
      const sourcePoint = map.latLngToContainerPoint([source.lat, source.lng]);
      const targetPoint = map.latLngToContainerPoint([target.lat, target.lng]);

      const newAttack = {
        id: attackId,
        start: { x: sourcePoint.x, y: sourcePoint.y },
        end: { x: targetPoint.x, y: targetPoint.y },
        source,
        target,
      };

      setAttacks(prev => [...prev, newAttack]);
      setAttackId(prev => prev + 1);
    };

    // Add initial attacks
    for (let i = 0; i < 5; i++) {
      setTimeout(() => addAttack(), i * 300);
    }

    // Add new attacks periodically
    const interval = setInterval(() => {
      const count = Math.floor(Math.random() * 2) + 1; // 1-2 attacks at a time
      for (let i = 0; i < count; i++) {
        addAttack();
      }
    }, 2000); // New attack every 2 seconds

    return () => clearInterval(interval);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attackId]);

  // Handle attack line completion - remove attack from state
  const handleAttackComplete = (id) => {
    setAttacks(prev => prev.filter(attack => attack.id !== id));
  };

  return (
    <div className="h-full w-full relative">
      <MapContainer
        center={[20, 0]} // Center the map
        zoom={2}
        minZoom={2}
        maxZoom={6}
        style={{ height: "500px", width: "100%" }}
        ref={mapRef}
        attributionControl={false}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {/* Source Markers with Pulsing Effect */}
        {attackSources.map((source) => (
          <motion.div
            key={`${source.name}-container`}
            initial={{ opacity: 0.7 }}
            animate={{ opacity: [0.5, 0.8, 0.5] }}
            transition={{
              repeat: Number.POSITIVE_INFINITY,
              duration: 2,
              ease: "easeInOut",
            }}
          >
            <Circle
              center={[source.lat, source.lng]}
              pathOptions={{ color: 'blue', fillColor: '#3b82f6', fillOpacity: 0.5 }}
              radius={300000} // 300km radius
            />
            <Marker position={[source.lat, source.lng]}>
              <Popup>
                <div className="text-center">
                  <h3 className="font-bold">{source.name}</h3>
                  <p>Attack Source</p>
                </div>
              </Popup>
            </Marker>
          </motion.div>
        ))}

        {/* Target Markers with Pulsing Effect */}
        {attackTargets.map((target) => (
          <motion.div
            key={`${target.name}-container`}
            initial={{ opacity: 0.7 }}
            animate={{ opacity: [0.5, 0.9, 0.5] }}
            transition={{
              repeat: Number.POSITIVE_INFINITY,
              duration: 3,
              ease: "easeInOut",
            }}
          >
            <Circle
              center={[target.lat, target.lng]}
              pathOptions={{ color: 'red', fillColor: '#ef4444', fillOpacity: 0.5 }}
              radius={200000} // 200km radius
            />
            <Marker position={[target.lat, target.lng]}>
              <Popup>
                <div className="text-center">
                  <h3 className="font-bold">{target.name}</h3>
                  <p>Attack Target</p>
                </div>
              </Popup>
            </Marker>
          </motion.div>
        ))}
      </MapContainer>

      {/* Render the attack lines */}
      {attacks.map((attack) => (
        <AttackLine
          key={attack.id}
          start={attack.start}
          end={attack.end}
          onComplete={() => handleAttackComplete(attack.id)}
        />
      ))}

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-white bg-opacity-90 p-3 rounded-md shadow-md z-[1000]">
        <h4 className="text-sm font-semibold mb-2">Map Legend</h4>
        <div className="space-y-1 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500" />
            <span>Attack Source</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <span>Attack Target</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span>Active Attack</span>
          </div>
        </div>
      </div>

      {/* Educational Note */}
      <div className="absolute top-4 right-4 bg-white bg-opacity-90 p-2 rounded-md shadow-md z-[1000] max-w-[200px]">
        <p className="text-xs">
          This is a simulation of cyber attacks for educational purposes.
        </p>
      </div>
    </div>
  );
}
