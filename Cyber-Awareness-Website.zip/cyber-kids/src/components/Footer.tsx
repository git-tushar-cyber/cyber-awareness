import Link from "next/link";
import Image from "next/image";

const footerLinks = [
  {
    title: "Learn",
    links: [
      { name: "Cyber Attacks", href: "/learn#attacks" },
      { name: "Phishing", href: "/learn#phishing" },
      { name: "Passwords", href: "/learn#passwords" },
      { name: "Online Safety", href: "/learn#safety" },
    ],
  },
  {
    title: "Games",
    links: [
      { name: "Security Quiz", href: "/games#quiz" },
      { name: "Password Challenge", href: "/games#password" },
      { name: "Cyber Detective", href: "/games#detective" },
    ],
  },
  {
    title: "Resources",
    links: [
      { name: "Dashboard", href: "/dashboard" },
      { name: "Leaderboard", href: "/leaderboard" },
      { name: "About Us", href: "/about" },
      { name: "Contact", href: "/contact" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="bg-violet-950 text-white pt-12 pb-6">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and Mission */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="/images/cyber-shield.png"
                alt="CyberKids Logo"
                width={40}
                height={40}
                className="bg-white rounded-full p-1"
              />
              <span className="font-bold text-xl">
                <span className="text-violet-300">Cyber</span>Kids
              </span>
            </Link>
            <p className="text-violet-200 text-sm mt-2">
              Making the internet safer for kids through fun, interactive learning!
            </p>
            <div className="flex items-center gap-4 mt-4">
              <Link href="https://twitter.com" className="text-violet-200 hover:text-white">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-twitter"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                </svg>
              </Link>
              <Link href="https://instagram.com" className="text-violet-200 hover:text-white">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-instagram"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                </svg>
              </Link>
              <Link href="https://youtube.com" className="text-violet-200 hover:text-white">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-youtube"
                >
                  <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
                  <path d="m10 15 5-3-5-3z" />
                </svg>
              </Link>
            </div>
          </div>

          {/* Footer Links */}
          {footerLinks.map((section) => (
            <div key={section.title} className="space-y-4">
              <h3 className="text-lg font-semibold text-violet-300">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-violet-200 hover:text-white transition-colors text-sm"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Copyright */}
        <div className="border-t border-violet-800 mt-8 pt-6 text-center text-violet-300 text-sm">
          <p>© {new Date().getFullYear()} CyberKids. All rights reserved.</p>
          <p className="mt-2">
            A kid-friendly educational platform for cyber security awareness.
          </p>
        </div>
      </div>
    </footer>
  );
}
