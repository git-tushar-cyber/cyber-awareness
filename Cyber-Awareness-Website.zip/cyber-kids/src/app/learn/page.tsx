"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function LearnPage() {
  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            className="text-4xl md:text-5xl font-bold text-violet-900 mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Learn Cyber Security
          </motion.h1>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Discover the world of cyber security through fun, easy-to-understand articles!
          </motion.p>
        </div>

        {/* Tabs for Different Topics */}
        <Tabs defaultValue="phishing" className="w-full max-w-4xl mx-auto">
          <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-8">
            <TabsTrigger value="phishing">Phishing</TabsTrigger>
            <TabsTrigger value="passwords">Passwords</TabsTrigger>
            <TabsTrigger value="malware">Malware</TabsTrigger>
            <TabsTrigger value="safety">Online Safety</TabsTrigger>
          </TabsList>

          {/* Phishing Tab */}
          <TabsContent value="phishing" className="mt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-2xl text-violet-800">What is Phishing?</CardTitle>
                <CardDescription>
                  Learn how to spot and avoid tricky online scams.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6 items-center">
                  <div>
                    <Image
                      src="/images/cyber-bug.png"
                      alt="Phishing Example"
                      width={400}
                      height={300}
                      className="rounded-lg border shadow-md"
                    />
                  </div>
                  <div className="space-y-4">
                    <p className="text-lg">
                      <strong className="text-violet-700">Phishing</strong> is when someone
                      pretends to be someone you trust to trick you into sharing personal information.
                    </p>
                    <p>
                      It's like fishing, but instead of trying to catch fish, bad people are trying to
                      "catch" your passwords, account numbers, or other private information.
                    </p>
                  </div>
                </div>

                <div className="bg-violet-50 rounded-lg p-6 border border-violet-100">
                  <h3 className="text-lg font-semibold text-violet-800 mb-4">How to Spot Phishing:</h3>
                  <ul className="space-y-3 list-disc pl-5">
                    <li>Check the sender's email address - is it from a strange or misspelled domain?</li>
                    <li>Look for spelling and grammar mistakes in the message</li>
                    <li>Be suspicious of urgent requests for your personal information</li>
                    <li>Hover over links (don't click!) to see where they really go</li>
                    <li>If something looks too good to be true, it probably is!</li>
                  </ul>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-yellow-700 flex items-center gap-2 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-500">
                      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                      <line x1="12" y1="9" x2="12" y2="13"/>
                      <line x1="12" y1="17" x2="12.01" y2="17"/>
                    </svg>
                    Remember
                  </h3>
                  <p>
                    Never share your passwords, account numbers, or personal information through
                    email, text, or on websites you don't trust. When in doubt, ask a parent or
                    teacher for help!
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Passwords Tab */}
          <TabsContent value="passwords" className="mt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-2xl text-violet-800">Strong Passwords</CardTitle>
                <CardDescription>
                  Learn how to create and protect your passwords.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6 items-center">
                  <div className="space-y-4">
                    <p className="text-lg">
                      <strong className="text-violet-700">Passwords</strong> are like the keys to your
                      online accounts. Just like you wouldn't give everyone a key to your house, you
                      should keep your passwords private and make them hard to guess.
                    </p>
                    <p>
                      Strong passwords help keep your accounts safe from hackers who might try to
                      break in and steal your information.
                    </p>
                  </div>
                  <div className="flex justify-center">
                    <Image
                      src="/images/icon-secure.png"
                      alt="Password Security"
                      width={250}
                      height={250}
                      className="rounded-lg shadow-md"
                    />
                  </div>
                </div>

                <div className="bg-violet-50 rounded-lg p-6 border border-violet-100">
                  <h3 className="text-lg font-semibold text-violet-800 mb-4">Making Strong Passwords:</h3>
                  <ul className="space-y-3 list-disc pl-5">
                    <li>Use at least 8 characters - longer is stronger!</li>
                    <li>Mix uppercase and lowercase letters (Aa, Bb, Cc)</li>
                    <li>Include numbers (1, 2, 3) and symbols (@, #, $)</li>
                    <li>Don't use easy-to-guess information like your name or birthday</li>
                    <li>Create a different password for each important account</li>
                  </ul>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-red-50 rounded-lg p-4 border border-red-100">
                    <h4 className="font-semibold text-red-700 mb-2">Weak Password Example</h4>
                    <p className="font-mono bg-white p-2 rounded border border-red-200">password123</p>
                    <p className="text-sm mt-2 text-red-600">This is easy to guess and used by many people.</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4 border border-green-100">
                    <h4 className="font-semibold text-green-700 mb-2">Strong Password Example</h4>
                    <p className="font-mono bg-white p-2 rounded border border-green-200">P@nda$tar75!</p>
                    <p className="text-sm mt-2 text-green-600">This mixes letters, numbers, and symbols, making it much harder to guess.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Malware Tab */}
          <TabsContent value="malware" className="mt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-2xl text-violet-800">Malware and Viruses</CardTitle>
                <CardDescription>
                  Learn about harmful software and how to protect your devices.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6 items-center">
                  <div>
                    <Image
                      src="/images/cyber-bug.png"
                      alt="Computer Virus"
                      width={400}
                      height={300}
                      className="rounded-lg border shadow-md"
                    />
                  </div>
                  <div className="space-y-4">
                    <p className="text-lg">
                      <strong className="text-violet-700">Malware</strong> is short for "malicious software" -
                      programs designed to damage or do unwanted things to your computer or device.
                    </p>
                    <p>
                      Just like how germs can make you sick, malware can make your computer "sick" by slowing
                      it down, stealing information, or even breaking it completely.
                    </p>
                  </div>
                </div>

                <div className="bg-violet-50 rounded-lg p-6 border border-violet-100">
                  <h3 className="text-lg font-semibold text-violet-800 mb-4">Types of Malware:</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <h4 className="font-semibold text-violet-700 mb-2">Viruses</h4>
                      <p className="text-sm">Programs that copy themselves and spread to other computers, like a real virus spreads between people.</p>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <h4 className="font-semibold text-violet-700 mb-2">Trojans</h4>
                      <p className="text-sm">Programs that look helpful but actually do harmful things, like the Trojan Horse in the ancient story!</p>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <h4 className="font-semibold text-violet-700 mb-2">Spyware</h4>
                      <p className="text-sm">Programs that secretly watch what you do on your computer and send that information to someone else.</p>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <h4 className="font-semibold text-violet-700 mb-2">Ransomware</h4>
                      <p className="text-sm">Programs that lock your files and demand money to unlock them.</p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-blue-700 mb-4">How to Stay Protected:</h3>
                  <ul className="space-y-3 list-disc pl-5">
                    <li>Keep your operating system and apps updated</li>
                    <li>Use antivirus software and keep it updated</li>
                    <li>Only download apps and files from trusted sources</li>
                    <li>Don't click on suspicious links or email attachments</li>
                    <li>Ask adults before installing new programs</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Online Safety Tab */}
          <TabsContent value="safety" className="mt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-2xl text-violet-800">Online Safety Tips</CardTitle>
                <CardDescription>
                  General tips for staying safe while enjoying the internet.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6 items-center">
                  <div className="space-y-4">
                    <p className="text-lg">
                      The internet is an amazing place to learn, play games, and connect with friends,
                      but it's important to use it safely and responsibly.
                    </p>
                    <p>
                      Just like how you follow safety rules in the real world (like looking both ways
                      before crossing the street), there are safety rules for the online world too!
                    </p>
                  </div>
                  <div>
                    <Image
                      src="/images/cyber-kids.jpg"
                      alt="Kids Online Safety"
                      width={400}
                      height={300}
                      className="rounded-lg border shadow-md"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-purple-50 rounded-lg p-6 border border-purple-100">
                    <h3 className="text-lg font-semibold text-purple-800 mb-4">Personal Information</h3>
                    <ul className="space-y-3 list-disc pl-5 text-gray-700">
                      <li>Never share your full name, address, phone number, or school name online</li>
                      <li>Don't post photos that show where you live or go to school</li>
                      <li>Use nicknames instead of your real name when playing online games</li>
                      <li>Never share passwords with friends (only trusted adults)</li>
                    </ul>
                  </div>

                  <div className="bg-blue-50 rounded-lg p-6 border border-blue-100">
                    <h3 className="text-lg font-semibold text-blue-800 mb-4">Online Communication</h3>
                    <ul className="space-y-3 list-disc pl-5 text-gray-700">
                      <li>Be kind online - don't say things you wouldn't say in person</li>
                      <li>Only communicate with people you know in real life</li>
                      <li>Never agree to meet someone you've only met online</li>
                      <li>Tell a trusted adult if someone is making you uncomfortable online</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-green-700 flex items-center gap-2 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                      <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                    The SMART Rules
                  </h3>
                  <ul className="space-y-3">
                    <li><strong className="text-green-700">S</strong> - Safe: Keep personal information private</li>
                    <li><strong className="text-green-700">M</strong> - Meet: Meeting someone you've only been in touch with online can be dangerous</li>
                    <li><strong className="text-green-700">A</strong> - Accepting: Accepting files, messages, or emails from people you don't know can lead to problems</li>
                    <li><strong className="text-green-700">R</strong> - Reliable: Someone online might be lying about who they are</li>
                    <li><strong className="text-green-700">T</strong> - Tell: Tell a trusted adult if something makes you feel uncomfortable</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
