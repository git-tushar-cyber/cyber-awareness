import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/utils";
import { Toaster } from "sonner";
import ClientBody from "./ClientBody"; // Fixed import to match actual export
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "CyberKids - Learn Cyber Security the Fun Way!",
  description: "A fun, interactive website for kids (standards 1-8) to learn about cyber security and online safety.",
};

export const viewport: Viewport = {
  themeColor: "#7c3aed", // Violet theme color
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={cn(inter.className, "min-h-screen flex flex-col bg-slate-50")}>
        <ClientBody>
          <Toaster position="top-right" richColors />
          <NavBar />
          <main className="flex-grow">
            {children}
          </main>
          <Footer />
        </ClientBody>
      </body>
    </html>
  );
}
