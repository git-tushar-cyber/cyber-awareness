"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            className="text-4xl md:text-5xl font-bold text-violet-900 mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            About CyberKids
          </motion.h1>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Our mission, vision, and the team behind this educational platform
          </motion.p>
        </div>

        {/* Mission and Vision */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="space-y-6"
          >
            <h2 className="text-3xl font-bold text-violet-800">Our Mission</h2>
            <p className="text-lg text-gray-700">
              Our mission is to empower children with the knowledge and skills they need to
              navigate the digital world safely and confidently.
            </p>
            <p className="text-lg text-gray-700">
              We believe that cyber security education should be fun, engaging, and accessible
              to all students from standards 1 to 8, regardless of their technical background.
            </p>
            <div className="mt-6 p-4 bg-violet-50 rounded-lg border border-violet-200">
              <h3 className="font-semibold text-violet-800 mb-2">CyberKids Goals:</h3>
              <ul className="space-y-2 list-disc pl-5">
                <li>Make cyber security concepts easy to understand for kids</li>
                <li>Create a safe online learning environment</li>
                <li>Teach practical skills through interactive games and activities</li>
                <li>Raise awareness about online dangers in a non-frightening way</li>
                <li>Build a community of cyber-smart young people</li>
              </ul>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex items-center justify-center"
          >
            <div className="relative w-full max-w-md h-[400px]">
              <Image
                src="/images/cyber-kids.jpg"
                alt="CyberKids Mission"
                fill
                className="object-cover rounded-lg shadow-lg"
              />
            </div>
          </motion.div>
        </div>

        {/* Why Cyber Education Matters */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="mb-16"
        >
          <Card className="bg-gradient-to-r from-violet-50 to-purple-50 border-violet-200">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-violet-800 mb-6">Why Cyber Education Matters for Kids</h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-5 rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-violet-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                      <circle cx="12" cy="12" r="10"/>
                      <line x1="12" y1="8" x2="12" y2="12"/>
                      <line x1="12" y1="16" x2="12.01" y2="16"/>
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-violet-700 mb-2">Digital Natives</h3>
                  <p className="text-gray-600">
                    Today's kids are growing up in a digital world. They need to learn cyber safety
                    skills just like they learn about road safety or stranger danger.
                  </p>
                </div>

                <div className="bg-white p-5 rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-violet-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-violet-700 mb-2">Growing Threats</h3>
                  <p className="text-gray-600">
                    As technology evolves, so do cyber threats. Early education helps children
                    develop good habits and critical thinking skills to stay safe online.
                  </p>
                </div>

                <div className="bg-white p-5 rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-violet-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                      <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/>
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-violet-700 mb-2">Future Ready</h3>
                  <p className="text-gray-600">
                    Learning cyber security concepts early prepares kids for a future where
                    digital skills and security awareness will be essential in most careers.
                  </p>
                </div>
              </div>

              <div className="mt-8 p-4 bg-white rounded-lg border border-violet-100">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                      <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                  </div>
                  <p className="text-gray-700">
                    <strong className="text-green-700">Did you know?</strong> According to research, children who receive cyber security
                    education are significantly more likely to report suspicious online activities and
                    practice safer internet habits throughout their lives.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Our Team */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold text-violet-800 mb-8 text-center">Meet Our Team</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4">
                <div className="w-24 h-24 rounded-full bg-violet-100 mx-auto mb-4 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-center text-violet-800">Sarah Johnson</h3>
                <p className="text-center text-violet-600 mb-2">Founder & Education Director</p>
                <p className="text-sm text-gray-600 text-center">
                  Former elementary school teacher with a passion for making technology accessible to young minds.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4">
                <div className="w-24 h-24 rounded-full bg-violet-100 mx-auto mb-4 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-center text-violet-800">Michael Chen</h3>
                <p className="text-center text-violet-600 mb-2">Cyber Security Expert</p>
                <p className="text-sm text-gray-600 text-center">
                  Brings 15 years of industry experience and makes complex security concepts fun for kids.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4">
                <div className="w-24 h-24 rounded-full bg-violet-100 mx-auto mb-4 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-center text-violet-800">Priya Patel</h3>
                <p className="text-center text-violet-600 mb-2">Game Designer</p>
                <p className="text-sm text-gray-600 text-center">
                  Creates our engaging quizzes and interactive activities that make learning about cyber security fun.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4">
                <div className="w-24 h-24 rounded-full bg-violet-100 mx-auto mb-4 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-center text-violet-800">David Rodriguez</h3>
                <p className="text-center text-violet-600 mb-2">Content Developer</p>
                <p className="text-sm text-gray-600 text-center">
                  Specializes in creating age-appropriate content that explains cyber concepts clearly to young learners.
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Contact CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.1 }}
          className="text-center"
        >
          <div className="bg-violet-900 text-white rounded-lg p-8 max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Join Our Mission</h2>
            <p className="mb-6">
              Are you passionate about teaching cyber security to kids? We're always looking for
              educators, security experts, and content creators to join our team!
            </p>
            <div className="flex justify-center">
              <a
                href="/contact"
                className="bg-white text-violet-900 px-6 py-3 rounded-md font-semibold hover:bg-violet-100 transition-colors"
              >
                Contact Us
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
