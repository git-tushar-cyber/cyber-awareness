"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

// Quiz data for different cybersecurity topics
const quizzes = [
  {
    id: "phishing",
    title: "Phishing Quiz",
    description: "Test your knowledge about online scams and phishing attacks!",
    image: "/images/cyber-bug.png",
    questions: [
      {
        question: "What is phishing?",
        options: [
          "A fun water sport",
          "Trying to catch someone's private information through fake messages",
          "A computer virus",
          "A type of password"
        ],
        correctAnswer: 1
      },
      {
        question: "Which of these is a sign of a phishing email?",
        options: [
          "It comes from someone you know and trust",
          "It has perfect spelling and grammar",
          "It asks for your password or personal information",
          "It was sent during school hours"
        ],
        correctAnswer: 2
      },
      {
        question: "What should you do if you get a message asking for your password?",
        options: [
          "Reply with your password right away",
          "Ignore it and tell a trusted adult",
          "Share only half of your password",
          "Give them a fake password"
        ],
        correctAnswer: 1
      },
      {
        question: "Why do people create phishing scams?",
        options: [
          "To help people learn about cybersecurity",
          "To steal information or money",
          "For fun, with no bad intentions",
          "To improve computer systems"
        ],
        correctAnswer: 1
      },
      {
        question: "If an email says you've won a prize but needs your bank details, what should you do?",
        options: [
          "Send the details - you might have really won!",
          "Tell all your friends about the prize",
          "Delete the email - it's probably a scam",
          "Reply asking for more information"
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: "password",
    title: "Password Challenge",
    description: "Learn how to create strong passwords and keep your accounts safe!",
    image: "/images/icon-secure.png",
    questions: [
      {
        question: "Which of these is the strongest password?",
        options: [
          "password123",
          "mybirthday",
          "R4inb0w%Unicorn!9",
          "qwerty"
        ],
        correctAnswer: 2
      },
      {
        question: "What makes a password strong?",
        options: [
          "Using only lowercase letters",
          "Using the same password for all your accounts",
          "Using your name and birthday",
          "Mixing letters, numbers, and symbols"
        ],
        correctAnswer: 3
      },
      {
        question: "How often should you change your important passwords?",
        options: [
          "Never - once you create a password, keep it forever",
          "Every few months",
          "Every day",
          "Only when you forget them"
        ],
        correctAnswer: 1
      },
      {
        question: "Who should you share your passwords with?",
        options: [
          "Your best friends",
          "Anyone who asks nicely",
          "Your parents or guardians only",
          "Everyone in your class"
        ],
        correctAnswer: 2
      },
      {
        question: "What should you do if someone finds out your password?",
        options: [
          "Nothing, it doesn't matter",
          "Change it immediately",
          "Share it with more people",
          "Use the same password for other accounts"
        ],
        correctAnswer: 1
      }
    ]
  },
  {
    id: "safety",
    title: "Online Safety Quiz",
    description: "Test your knowledge about staying safe online!",
    image: "/images/cyber-kids.jpg",
    questions: [
      {
        question: "What personal information should you NOT share online?",
        options: [
          "Your favorite color",
          "Your home address",
          "Your opinion about a movie",
          "The name of your pet"
        ],
        correctAnswer: 1
      },
      {
        question: "What should you do if a stranger online asks to meet you in person?",
        options: [
          "Agree to meet them at your house",
          "Agree to meet them at a public place",
          "Say no and tell a trusted adult immediately",
          "Give them your phone number instead"
        ],
        correctAnswer: 2
      },
      {
        question: "What is the best way to behave in online games or chat rooms?",
        options: [
          "Be respectful and kind, just like in real life",
          "Say whatever you want because no one knows who you are",
          "Use bad language to seem cool",
          "Make fun of other players"
        ],
        correctAnswer: 0
      },
      {
        question: "What should you do if you see cyberbullying happening?",
        options: [
          "Join in so you don't become a target",
          "Ignore it completely",
          "Take screenshots and tell a trusted adult",
          "Tell the bully they're being mean in a public comment"
        ],
        correctAnswer: 2
      },
      {
        question: "What does the 'S' in the SMART online safety rules stand for?",
        options: [
          "Smile",
          "Safe",
          "Secret",
          "Sharing"
        ],
        correctAnswer: 1
      }
    ]
  }
];

const Quiz = ({ quiz, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleOptionSelect = (optionIndex) => {
    if (!submitted) {
      setSelectedOption(optionIndex);
    }
  };

  const handleSubmit = () => {
    if (selectedOption === null) {
      toast.error("Please select an answer first!");
      return;
    }

    setSubmitted(true);

    if (selectedOption === quiz.questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
      toast.success("Correct answer! 🎉");
    } else {
      toast.error("Oops! That's not right. Try to remember the correct answer!");
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setSubmitted(false);

    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
      onComplete(score);
    }
  };

  const getScoreMessage = () => {
    const percentage = (score / quiz.questions.length) * 100;

    if (percentage >= 80) return "Amazing job! You're a cyber security expert! 🌟";
    if (percentage >= 60) return "Good job! You know a lot about staying safe online! 👍";
    return "Keep learning! Practice makes perfect in cyber security! 📚";
  };

  const getOptionClassName = (index) => {
    let className = "p-4 rounded-lg border-2 cursor-pointer transition-all";

    if (!submitted) {
      className += selectedOption === index
        ? " border-violet-500 bg-violet-50"
        : " border-gray-200 hover:border-violet-300";
    } else {
      if (index === quiz.questions[currentQuestion].correctAnswer) {
        className += " border-green-500 bg-green-50";
      } else if (index === selectedOption) {
        className += " border-red-500 bg-red-50";
      } else {
        className += " border-gray-200 opacity-60";
      }
    }

    return className;
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      {!showResults ? (
        <>
          <CardHeader>
            <CardTitle className="text-xl text-violet-800">
              Question {currentQuestion + 1} of {quiz.questions.length}
            </CardTitle>
            <CardDescription>
              {quiz.questions[currentQuestion].question}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {quiz.questions[currentQuestion].options.map((option, index) => (
              <div
                key={index}
                className={getOptionClassName(index)}
                onClick={() => handleOptionSelect(index)}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                    selectedOption === index ? 'bg-violet-500 text-white' : 'bg-gray-100'
                  } ${
                    submitted && index === quiz.questions[currentQuestion].correctAnswer ? 'bg-green-500 text-white' : ''
                  } ${
                    submitted && index === selectedOption && index !== quiz.questions[currentQuestion].correctAnswer ? 'bg-red-500 text-white' : ''
                  }`}>
                    {String.fromCharCode(65 + index)}
                  </div>
                  <span>{option}</span>
                </div>
              </div>
            ))}
          </CardContent>
          <CardFooter className="flex justify-between">
            {!submitted ? (
              <Button onClick={handleSubmit} className="bg-violet-600 hover:bg-violet-700">
                Submit Answer
              </Button>
            ) : (
              <Button onClick={handleNext} className="bg-violet-600 hover:bg-violet-700">
                {currentQuestion < quiz.questions.length - 1 ? "Next Question" : "See Results"}
              </Button>
            )}
            <div className="text-sm text-gray-500">
              Score: {score}/{quiz.questions.length}
            </div>
          </CardFooter>
        </>
      ) : (
        <>
          <CardHeader>
            <CardTitle className="text-xl text-violet-800">Quiz Complete!</CardTitle>
            <CardDescription>
              Here's how you did on the {quiz.title}
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center py-6">
            <div className="text-5xl font-bold text-violet-700 mb-4">
              {score}/{quiz.questions.length}
            </div>
            <p className="text-lg mb-6">{getScoreMessage()}</p>

            {score === quiz.questions.length ? (
              <Image
                src="/images/cyber-shield.png"
                alt="Perfect Score Trophy"
                width={150}
                height={150}
                className="mx-auto mb-4"
              />
            ) : (
              <Image
                src="/images/cyber-bear.png"
                alt="Quiz Completed"
                width={150}
                height={150}
                className="mx-auto mb-4"
              />
            )}

            <p className="text-gray-600">
              Keep learning and practicing to become a cyber security expert!
            </p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button
              onClick={() => {
                setCurrentQuestion(0);
                setSelectedOption(null);
                setScore(0);
                setShowResults(false);
                setSubmitted(false);
              }}
              className="bg-violet-600 hover:bg-violet-700 mr-4"
            >
              Try Again
            </Button>
            <Button
              variant="outline"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            >
              Choose Another Quiz
            </Button>
          </CardFooter>
        </>
      )}
    </Card>
  );
};

export default function GamesPage() {
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);
  const [playerName, setPlayerName] = useState("");

  const handleQuizSelect = (quizId) => {
    const quiz = quizzes.find(q => q.id === quizId);
    setSelectedQuiz(quiz);
    window.scrollTo({ top: document.querySelector('.quiz-section').offsetTop - 100, behavior: 'smooth' });
  };

  const handleQuizComplete = (score) => {
    if (playerName) {
      const newScore = {
        name: playerName,
        quiz: selectedQuiz.title,
        score: score,
        date: new Date().toLocaleDateString()
      };

      setLeaderboard([...leaderboard, newScore].sort((a, b) => b.score - a.score));

      // Show congratulations toast
      toast.success(`Congratulations ${playerName}! You scored ${score}/${selectedQuiz.questions.length}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            className="text-4xl md:text-5xl font-bold text-violet-900 mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Cyber Security Games
          </motion.h1>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Test your knowledge and learn more about cyber security through our fun interactive quizzes!
          </motion.p>
        </div>

        {/* Player Name Input */}
        {!playerName && (
          <motion.div
            className="max-w-md mx-auto mb-12 bg-white p-6 rounded-lg shadow-md"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h2 className="text-xl font-semibold text-violet-900 mb-4">Enter Your Name to Start</h2>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Your name"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && playerName && toast.success(`Welcome, ${playerName}! Choose a quiz to start playing.`)}
              />
              <Button
                className="bg-violet-600 hover:bg-violet-700"
                onClick={() => {
                  if (playerName) {
                    toast.success(`Welcome, ${playerName}! Choose a quiz to start playing.`);
                  } else {
                    toast.error("Please enter your name first!");
                  }
                }}
              >
                Start
              </Button>
            </div>
          </motion.div>
        )}

        {/* Quiz Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {quizzes.map((quiz, index) => (
            <motion.div
              key={quiz.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 + 0.4 }}
            >
              <Card className="h-full flex flex-col hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl text-violet-800">{quiz.title}</CardTitle>
                  <CardDescription>{quiz.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="h-48 relative mb-4">
                    <Image
                      src={quiz.image}
                      alt={quiz.title}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <p className="text-sm text-gray-500">{quiz.questions.length} questions</p>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full bg-violet-600 hover:bg-violet-700"
                    onClick={() => handleQuizSelect(quiz.id)}
                    disabled={!playerName}
                  >
                    Start Quiz
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Selected Quiz */}
        <div className="quiz-section">
          {selectedQuiz && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="mb-12"
            >
              <h2 className="text-2xl font-bold text-violet-900 mb-6 text-center">{selectedQuiz.title}</h2>
              <Quiz quiz={selectedQuiz} onComplete={handleQuizComplete} />
            </motion.div>
          )}
        </div>

        {/* Mini Leaderboard */}
        {leaderboard.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="mt-16"
          >
            <h2 className="text-2xl font-bold text-violet-900 mb-6 text-center">Your Scores</h2>
            <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
              <table className="w-full">
                <thead className="bg-violet-50">
                  <tr>
                    <th className="py-3 px-4 text-left text-violet-800 font-semibold">Name</th>
                    <th className="py-3 px-4 text-left text-violet-800 font-semibold">Quiz</th>
                    <th className="py-3 px-4 text-left text-violet-800 font-semibold">Score</th>
                    <th className="py-3 px-4 text-left text-violet-800 font-semibold">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {leaderboard.map((entry, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-violet-50/30'}>
                      <td className="py-3 px-4 border-t border-gray-100">{entry.name}</td>
                      <td className="py-3 px-4 border-t border-gray-100">{entry.quiz}</td>
                      <td className="py-3 px-4 border-t border-gray-100">{entry.score}</td>
                      <td className="py-3 px-4 border-t border-gray-100">{entry.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
