"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Image from "next/image";

// Sample leaderboard data - in a real app, this would come from a database
const sampleData = [
  {
    id: 1,
    name: "Alex Johnson",
    quiz: "Phishing Quiz",
    score: 5,
    date: "2025-04-02",
    avatar: "👧"
  },
  {
    id: 2,
    name: "Sam Rodriguez",
    quiz: "Password Challenge",
    score: 5,
    date: "2025-04-01",
    avatar: "👦"
  },
  {
    id: 3,
    name: "Jamie Smith",
    quiz: "Online Safety Quiz",
    score: 4,
    date: "2025-04-05",
    avatar: "👧"
  },
  {
    id: 4,
    name: "Taylor Lee",
    quiz: "Phishing Quiz",
    score: 4,
    date: "2025-04-03",
    avatar: "👦"
  },
  {
    id: 5,
    name: "Jordan Wilson",
    quiz: "Password Challenge",
    score: 4,
    date: "2025-04-04",
    avatar: "👧"
  },
  {
    id: 6,
    name: "Casey Brown",
    quiz: "Online Safety Quiz",
    score: 3,
    date: "2025-04-02",
    avatar: "👦"
  },
  {
    id: 7,
    name: "Riley Garcia",
    quiz: "Phishing Quiz",
    score: 3,
    date: "2025-04-01",
    avatar: "👧"
  },
  {
    id: 8,
    name: "Avery Martinez",
    quiz: "Password Challenge",
    score: 3,
    date: "2025-04-05",
    avatar: "👦"
  },
  {
    id: 9,
    name: "Quinn Thomas",
    quiz: "Online Safety Quiz",
    score: 2,
    date: "2025-04-03",
    avatar: "👧"
  },
  {
    id: 10,
    name: "Reese Jackson",
    quiz: "Phishing Quiz",
    score: 2,
    date: "2025-04-04",
    avatar: "👦"
  }
];

// Define the filters for the leaderboard
const quizFilters = [
  { label: "All Quizzes", value: "all" },
  { label: "Phishing Quiz", value: "Phishing Quiz" },
  { label: "Password Challenge", value: "Password Challenge" },
  { label: "Online Safety Quiz", value: "Online Safety Quiz" }
];

export default function LeaderboardPage() {
  const [leaderboardData, setLeaderboardData] = useState(sampleData);
  const [filter, setFilter] = useState("all");

  // Apply filtering
  useEffect(() => {
    if (filter === "all") {
      setLeaderboardData(sampleData);
    } else {
      setLeaderboardData(sampleData.filter(item => item.quiz === filter));
    }
  }, [filter]);

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            className="text-4xl md:text-5xl font-bold text-violet-900 mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            CyberKids Leaderboard
          </motion.h1>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            See who's topping the charts in our cyber security games!
          </motion.p>
        </div>

        {/* Top 3 Winners */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold text-center text-violet-800 mb-8">🏆 Hall of Fame 🏆</h2>

          <div className="flex flex-col md:flex-row justify-center items-end md:items-end space-y-6 md:space-y-0 md:space-x-6">
            {/* Second Place */}
            <div className="order-2 md:order-1">
              <div className="text-center mb-2">
                <span className="inline-block w-8 h-8 rounded-full bg-violet-200 text-violet-800 font-bold text-xl flex items-center justify-center">2</span>
              </div>
              <div className="bg-white rounded-lg shadow-md px-6 pt-6 pb-4 w-full md:w-64 relative">
                <div className="w-20 h-20 mx-auto bg-violet-100 rounded-full flex items-center justify-center mb-4">
                  <span className="text-5xl">{leaderboardData[1]?.avatar || "👦"}</span>
                </div>
                <h3 className="font-bold text-lg text-center text-violet-800 truncate">{leaderboardData[1]?.name || "Player 2"}</h3>
                <p className="text-sm text-gray-500 text-center mb-2">{leaderboardData[1]?.quiz || "Quiz"}</p>
                <div className="bg-violet-100 rounded-full py-1 px-3 text-center">
                  <span className="font-bold text-violet-800">{leaderboardData[1]?.score || 0} points</span>
                </div>
                <div className="absolute top-2 right-2">
                  <div className="w-8 h-8">
                    <Image src="/images/icon-shield.png" alt="Silver Medal" width={32} height={32} />
                  </div>
                </div>
              </div>
            </div>

            {/* First Place - Taller */}
            <div className="order-1 md:order-2">
              <div className="text-center mb-2">
                <span className="inline-block w-10 h-10 rounded-full bg-yellow-200 text-yellow-800 font-bold text-2xl flex items-center justify-center">1</span>
              </div>
              <div className="bg-white rounded-lg shadow-md px-6 pt-8 pb-6 w-full md:w-72 border-2 border-yellow-300 relative">
                <div className="w-24 h-24 mx-auto bg-yellow-100 rounded-full flex items-center justify-center mb-4">
                  <span className="text-6xl">{leaderboardData[0]?.avatar || "👑"}</span>
                </div>
                <h3 className="font-bold text-xl text-center text-violet-900 truncate">{leaderboardData[0]?.name || "Player 1"}</h3>
                <p className="text-sm text-gray-500 text-center mb-3">{leaderboardData[0]?.quiz || "Quiz"}</p>
                <div className="bg-yellow-100 rounded-full py-2 px-4 text-center">
                  <span className="font-bold text-yellow-800">{leaderboardData[0]?.score || 0} points</span>
                </div>
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-4">
                  <span className="text-2xl">👑</span>
                </div>
                <div className="absolute top-2 right-2">
                  <div className="w-10 h-10">
                    <Image src="/images/cyber-shield.png" alt="Gold Medal" width={40} height={40} />
                  </div>
                </div>
              </div>
            </div>

            {/* Third Place */}
            <div className="order-3">
              <div className="text-center mb-2">
                <span className="inline-block w-8 h-8 rounded-full bg-orange-200 text-orange-800 font-bold text-xl flex items-center justify-center">3</span>
              </div>
              <div className="bg-white rounded-lg shadow-md px-6 pt-6 pb-4 w-full md:w-64 relative">
                <div className="w-20 h-20 mx-auto bg-orange-100 rounded-full flex items-center justify-center mb-4">
                  <span className="text-5xl">{leaderboardData[2]?.avatar || "👧"}</span>
                </div>
                <h3 className="font-bold text-lg text-center text-violet-800 truncate">{leaderboardData[2]?.name || "Player 3"}</h3>
                <p className="text-sm text-gray-500 text-center mb-2">{leaderboardData[2]?.quiz || "Quiz"}</p>
                <div className="bg-orange-100 rounded-full py-1 px-3 text-center">
                  <span className="font-bold text-orange-800">{leaderboardData[2]?.score || 0} points</span>
                </div>
                <div className="absolute top-2 right-2">
                  <div className="w-8 h-8">
                    <Image src="/images/icon-secure.png" alt="Bronze Medal" width={32} height={32} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Leaderboard Table */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                <div>
                  <CardTitle className="text-2xl text-violet-800">Game Leaders</CardTitle>
                  <CardDescription>All-time highest scores in our cyber security games</CardDescription>
                </div>

                {/* Filter Controls */}
                <div className="mt-4 md:mt-0">
                  <div className="flex flex-wrap gap-2">
                    {quizFilters.map((quizFilter) => (
                      <button
                        key={quizFilter.value}
                        onClick={() => setFilter(quizFilter.value)}
                        className={`px-3 py-1 text-sm rounded-full transition-colors ${
                          filter === quizFilter.value
                            ? "bg-violet-600 text-white"
                            : "bg-violet-100 text-violet-800 hover:bg-violet-200"
                        }`}
                      >
                        {quizFilter.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="py-3 px-4 text-left text-sm font-semibold text-gray-500">RANK</th>
                      <th className="py-3 px-4 text-left text-sm font-semibold text-gray-500">PLAYER</th>
                      <th className="py-3 px-4 text-left text-sm font-semibold text-gray-500">QUIZ</th>
                      <th className="py-3 px-4 text-left text-sm font-semibold text-gray-500">SCORE</th>
                      <th className="py-3 px-4 text-left text-sm font-semibold text-gray-500">DATE</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leaderboardData.map((entry, index) => (
                      <tr
                        key={entry.id}
                        className={index % 2 === 0 ? "bg-white" : "bg-violet-50/30"}
                      >
                        <td className="py-3 px-4 border-b border-gray-100">
                          <div className="flex items-center">
                            <span className={`
                              w-8 h-8 rounded-full flex items-center justify-center mr-2 text-sm font-medium
                              ${index === 0 ? "bg-yellow-100 text-yellow-800" :
                                index === 1 ? "bg-violet-100 text-violet-800" :
                                index === 2 ? "bg-orange-100 text-orange-800" :
                                "bg-gray-100 text-gray-800"}
                            `}>
                              {index + 1}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4 border-b border-gray-100">
                          <div className="flex items-center">
                            <span className="text-xl mr-2">{entry.avatar}</span>
                            <span className="font-medium">{entry.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 border-b border-gray-100 text-gray-600">
                          {entry.quiz}
                        </td>
                        <td className="py-3 px-4 border-b border-gray-100">
                          <span className="font-medium text-violet-700">{entry.score} / 5</span>
                        </td>
                        <td className="py-3 px-4 border-b border-gray-100 text-gray-500">
                          {new Date(entry.date).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* How to Get on the Leaderboard */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="mt-16 max-w-4xl mx-auto"
        >
          <Card className="bg-violet-50 border border-violet-200">
            <CardHeader>
              <CardTitle className="text-xl text-violet-800">How to Get on the Leaderboard</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-violet-200 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="font-bold text-violet-700">1</span>
                </div>
                <div>
                  <h3 className="font-semibold text-violet-700 mb-1">Play Our Games</h3>
                  <p className="text-gray-700">
                    Go to the Games section and choose from a variety of cyber security quizzes and games.
                    Each game tests your knowledge on different online safety topics.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-violet-200 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="font-bold text-violet-700">2</span>
                </div>
                <div>
                  <h3 className="font-semibold text-violet-700 mb-1">Answer Correctly</h3>
                  <p className="text-gray-700">
                    Each correct answer earns you points. The more points you earn, the higher your score
                    will be. Try to answer all questions correctly to get the maximum score!
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-violet-200 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="font-bold text-violet-700">3</span>
                </div>
                <div>
                  <h3 className="font-semibold text-violet-700 mb-1">Enter Your Name</h3>
                  <p className="text-gray-700">
                    After completing a game, enter your name to save your score to the leaderboard.
                    Make sure to remember the name you used if you want to track your progress!
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-violet-200 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="font-bold text-violet-700">4</span>
                </div>
                <div>
                  <h3 className="font-semibold text-violet-700 mb-1">Keep Practicing</h3>
                  <p className="text-gray-700">
                    The more you play, the better you'll get! Learn from any mistakes and try again
                    to improve your score and climb up the leaderboard ranks.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
