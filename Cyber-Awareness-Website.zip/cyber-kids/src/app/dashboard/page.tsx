"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import dynamic from "next/dynamic";

// Dynamically import the MapContainer component from react-leaflet
// This prevents SSR issues with Leaflet which requires a browser environment
const MapWithNoSSR = dynamic(
  () => import("@/components/CyberMap"),
  { ssr: false }
);

// Top attack types for the dashboard
const attackTypes = [
  { type: "Phishing", count: 1547, change: "+12%", color: "bg-red-500" },
  { type: "Malware", count: 986, change: "+5%", color: "bg-orange-500" },
  { type: "Ransomware", count: 632, change: "-3%", color: "bg-yellow-500" },
  { type: "DDoS", count: 419, change: "+22%", color: "bg-green-500" },
];

// Most targeted sectors
const targetedSectors = [
  { name: "Education", percentage: 28 },
  { name: "Healthcare", percentage: 22 },
  { name: "Finance", percentage: 18 },
  { name: "Government", percentage: 15 },
  { name: "Retail", percentage: 10 },
  { name: "Other", percentage: 7 },
];

// Recent cyber attack alerts for the feed
const initialAlerts = [
  { id: 1, type: "Phishing", location: "United States", time: "2 mins ago" },
  { id: 2, type: "Malware", location: "Germany", time: "5 mins ago" },
  { id: 3, type: "DDoS", location: "Japan", time: "8 mins ago" },
  { id: 4, type: "Ransomware", location: "Brazil", time: "12 mins ago" },
  { id: 5, type: "Data Breach", location: "Australia", time: "15 mins ago" },
];

export default function DashboardPage() {
  const [alerts, setAlerts] = useState(initialAlerts);
  const [attackCount, setAttackCount] = useState(3584);
  const countRef = useRef(3584);
  const alertIdRef = useRef(6);

  // Simulate new alerts coming in
  useEffect(() => {
    const alertInterval = setInterval(() => {
      const types = ["Phishing", "Malware", "DDoS", "Ransomware", "Data Breach"];
      const locations = ["United States", "China", "Russia", "India", "United Kingdom", "Brazil", "Germany", "Japan", "Australia", "Canada"];

      const newAlert = {
        id: alertIdRef.current++,
        type: types[Math.floor(Math.random() * types.length)],
        location: locations[Math.floor(Math.random() * locations.length)],
        time: "Just now"
      };

      // Add the new alert and update time of existing alerts
      setAlerts(prev => {
        const updated = prev.map(alert => {
          if (alert.time === "Just now") return { ...alert, time: "1 min ago" };
          if (alert.time === "1 min ago") return { ...alert, time: "2 mins ago" };
          if (alert.time === "2 mins ago") return { ...alert, time: "5 mins ago" };
          if (alert.time === "5 mins ago") return { ...alert, time: "8 mins ago" };
          if (alert.time === "8 mins ago") return { ...alert, time: "12 mins ago" };
          if (alert.time === "12 mins ago") return { ...alert, time: "15 mins ago" };
          return alert;
        });

        // Keep only the 5 most recent alerts
        return [newAlert, ...updated.slice(0, 4)];
      });

      // Increment attack count
      countRef.current += Math.floor(Math.random() * 10) + 1;
      setAttackCount(countRef.current);

    }, 8000); // New alert every 8 seconds

    return () => clearInterval(alertInterval);
  }, []);

  // Update alert times
  useEffect(() => {
    const timeInterval = setInterval(() => {
      setAlerts(prev =>
        prev.map(alert => {
          if (alert.time === "Just now") return alert;
          if (alert.time === "1 min ago") return alert;
          if (alert.time === "2 mins ago") return alert;
          if (alert.time === "5 mins ago") return alert;
          if (alert.time === "8 mins ago") return alert;
          if (alert.time === "12 mins ago") return alert;
          if (alert.time === "15 mins ago") return alert;

          // Extract number from time string
          const timeMatch = alert.time.match(/(\d+)/);
          if (timeMatch) {
            const num = Number.parseInt(timeMatch[0], 10);
            return { ...alert, time: `${num + 1} mins ago` };
          }
          return alert;
        })
      );
    }, 60000); // Update every minute

    return () => clearInterval(timeInterval);
  }, []);

  const getAlertColor = (type) => {
    switch (type) {
      case "Phishing": return "bg-red-500";
      case "Malware": return "bg-orange-500";
      case "DDoS": return "bg-green-500";
      case "Ransomware": return "bg-yellow-500";
      case "Data Breach": return "bg-blue-500";
      default: return "bg-purple-500";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            className="text-4xl md:text-5xl font-bold text-violet-900 mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Live Cyber Security Dashboard
          </motion.h1>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Watch cyber attacks happening around the world in real-time
          </motion.p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Total Attacks</CardTitle>
                <CardDescription>Today</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-violet-700">{attackCount.toLocaleString()}</div>
                <p className="text-sm text-green-600 mt-1">+3.2% from yesterday</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Countries</CardTitle>
                <CardDescription>With Cyber Attacks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-violet-700">162</div>
                <p className="text-sm text-orange-600 mt-1">Almost every country</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Top Attack</CardTitle>
                <CardDescription>Most Common Type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-violet-700">Phishing</div>
                <p className="text-sm text-red-600 mt-1">43% of all attacks</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Safest Region</CardTitle>
                <CardDescription>Least Attacks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-violet-700">Antarctica</div>
                <p className="text-sm text-blue-600 mt-1">Very few internet users</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Map and Sidebar Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Map Section */}
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <Card className="overflow-hidden">
              <CardHeader className="bg-violet-50">
                <CardTitle className="text-xl text-violet-800">Global Cyber Attack Map</CardTitle>
                <CardDescription>
                  Simulated attacks based on real-world patterns
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-[500px] w-full relative">
                  <MapWithNoSSR />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Sidebar with Attack Types and Live Feed */}
          <div className="space-y-8">
            {/* Attack Types */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-violet-800">Attack Types</CardTitle>
                  <CardDescription>Most common cyber attacks today</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {attackTypes.map((attack, index) => (
                    <div key={attack.type} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${attack.color}`} />
                        <span>{attack.type}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{attack.count}</span>
                        <span className={attack.change.startsWith("+") ? "text-green-500" : "text-red-500"}>
                          {attack.change}
                        </span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>

            {/* Live Feed */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-violet-800">Live Attack Feed</CardTitle>
                  <CardDescription>Recent cyber attack alerts</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 max-h-[300px] overflow-auto pr-2">
                  {alerts.map((alert) => (
                    <motion.div
                      key={alert.id}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className="flex items-center gap-3 border-b border-gray-100 pb-3"
                    >
                      <div className={`w-3 h-3 rounded-full ${getAlertColor(alert.type)}`} />
                      <div className="flex-grow">
                        <div className="font-medium">{alert.type} Attack</div>
                        <div className="text-sm text-gray-500">Location: {alert.location}</div>
                      </div>
                      <div className="text-xs text-gray-400 whitespace-nowrap">{alert.time}</div>
                    </motion.div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* Targeted Sectors Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mb-12"
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-violet-800">Most Targeted Sectors</CardTitle>
              <CardDescription>Industries most affected by cyber attacks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {targetedSectors.map((sector) => (
                  <div key={sector.name}>
                    <div className="flex justify-between mb-1">
                      <span className="font-medium">{sector.name}</span>
                      <span className="text-gray-500">{sector.percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div
                        className="bg-violet-600 h-2.5 rounded-full"
                        style={{ width: `${sector.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* What This Means for Kids */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
        >
          <Card className="bg-violet-50 border-violet-200">
            <CardHeader>
              <CardTitle className="text-xl text-violet-800">What Does This Mean For Kids?</CardTitle>
              <CardDescription>Understanding the cyber attack dashboard</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h3 className="font-semibold text-violet-700">Why Do Cyber Attacks Happen?</h3>
                  <p>
                    Cyber attacks happen when bad people try to steal information, cause damage,
                    or make money by tricking computers and the people who use them.
                  </p>
                  <p>
                    Just like there are rules and police officers in real life, we need rules
                    and protections in the online world too!
                  </p>
                </div>
                <div className="space-y-3">
                  <h3 className="font-semibold text-violet-700">How Can You Stay Safe?</h3>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Use strong passwords and keep them secret</li>
                    <li>Be careful about what links you click</li>
                    <li>Don't share personal information online</li>
                    <li>Ask an adult before downloading anything</li>
                    <li>Keep your devices updated with the latest security</li>
                  </ul>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-violet-200 mt-4">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <Image
                      src="/images/cyber-shield.png"
                      alt="Cyber Security Shield"
                      width={60}
                      height={60}
                    />
                  </div>
                  <div>
                    <h3 className="font-semibold text-violet-700 mb-1">Remember!</h3>
                    <p>
                      This dashboard shows simulated cyber attacks based on real-world patterns.
                      By learning about cyber security early, you're already becoming a cyber
                      safety expert! If you ever feel unsafe online, talk to a trusted adult right away.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
