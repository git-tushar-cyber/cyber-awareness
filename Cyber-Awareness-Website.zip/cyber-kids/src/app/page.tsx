"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";

// Features that will be displayed in the Features Section
const features = [
  {
    id: "learn",
    title: "Learn",
    description: "Fun, easy-to-understand articles about different types of cyber threats and how to stay safe.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-violet-600">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
      </svg>
    ),
  },
  {
    id: "games",
    title: "Games",
    description: "Test your knowledge with interactive quizzes and fun games about cybersecurity.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-violet-600">
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 6.087c0-.355.186-.676.401-.959.221-.29.349-.634.349-1.003 0-1.036-1.007-1.875-2.25-1.875s-2.25.84-2.25 1.875c0 .369.128.713.349 1.003.215.283.401.604.401.959v0a.64.64 0 0 1-.657.643 48.39 48.39 0 0 1-4.163-.3c.186 1.613.293 3.25.315 4.907a.656.656 0 0 1-.658.663v0c-.355 0-.676-.186-.959-.401a1.647 1.647 0 0 0-1.003-.349c-1.036 0-1.875 1.007-1.875 2.25s.84 2.25 1.875 2.25c.369 0 .713-.128 1.003-.349.283-.215.604-.401.959-.401v0c.31 0 .555.26.532.57a48.039 48.039 0 0 1-.642 5.056c1.518.19 3.058.309 4.616.354a.64.64 0 0 0 .657-.643v0c0-.355-.186-.676-.401-.959a1.647 1.647 0 0 1-.349-1.003c0-1.035 1.008-1.875 2.25-1.875 1.243 0 2.25.84 2.25 1.875 0 .369-.128.713-.349 1.003-.215.283-.4.604-.4.959v0c0 .333.277.599.61.58a48.1 48.1 0 0 0 5.427-.63 48.05 48.05 0 0 0 .582-4.717.532.532 0 0 0-.533-.57v0c-.355 0-.676.186-.959.401-.29.221-.634.349-1.003.349-1.035 0-1.875-1.007-1.875-2.25s.84-2.25 1.875-2.25c.37 0 .713.128 1.003.349.283.215.604.401.96.401v0a.656.656 0 0 0 .658-.663 48.422 48.422 0 0 0-.37-5.36c-1.886.342-3.81.574-5.766.689a.578.578 0 0 1-.61-.58v0Z" />
      </svg>
    ),
  },
  {
    id: "dashboard",
    title: "Live Cyber Dashboard",
    description: "See real-time cyber attacks happening around the world on our interactive map.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-violet-600">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25m18 0A2.25 2.25 0 0 0 18.75 3H5.25A2.25 2.25 0 0 0 3 5.25m18 0V12a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 12V5.25" />
      </svg>
    ),
  },
];

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative w-full h-[500px] flex flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-violet-950 to-indigo-900 text-white">
        <div className="absolute inset-0 w-full h-full bg-black/20" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="z-10 text-center px-4 md:px-8"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-4 tracking-tight">
            <span className="text-violet-300">Cyber</span>Kids
          </h1>
          <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8">
            Your adventure into the digital world of online safety starts here!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/learn">
              <Button size="lg" className="bg-violet-600 hover:bg-violet-700">
                Start Learning
              </Button>
            </Link>
            <Link href="/games">
              <Button size="lg" variant="outline" className="border-violet-400 text-white hover:bg-violet-800">
                Play Games
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Animated Elements */}
        <motion.div
          className="absolute left-[10%] top-[20%]"
          animate={{
            y: [0, -15, 0],
            rotate: [-5, 5, -5],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: 4,
          }}
        >
          <Image
            src="/images/icon-shield.png"
            alt="Security Shield"
            width={80}
            height={80}
            className="opacity-70"
          />
        </motion.div>

        <motion.div
          className="absolute right-[12%] top-[25%]"
          animate={{
            y: [0, 20, 0],
            rotate: [5, -5, 5],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: 5,
            delay: 0.5
          }}
        >
          <Image
            src="/images/icon-secure.png"
            alt="Lock Icon"
            width={70}
            height={70}
            className="opacity-70"
          />
        </motion.div>
      </section>

      {/* Mission Statement */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Image
                src="/images/cyber-kids.jpg"
                alt="Kids learning about cyber security"
                width={500}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <h2 className="text-3xl font-bold text-violet-900">Our Mission</h2>
              <p className="text-gray-700 text-lg">
                CyberKids is on a mission to make the internet a safer place for children! We believe that teaching
                cyber security from a young age is essential in today's digital world.
              </p>
              <p className="text-gray-700 text-lg">
                Through fun, interactive learning experiences, we help kids in standards 1-8 understand potential
                online dangers and develop the skills they need to stay safe online.
              </p>
              <div className="pt-4">
                <Link href="/about">
                  <Button className="bg-violet-600 hover:bg-violet-700">
                    Learn More About Us
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-gray-100">
        <div className="max-w-6xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold text-violet-900 mb-4">What You'll Find Here</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Explore our site to learn about staying safe online through fun activities and resources!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {features.map((feature) => (
            <motion.div
              key={feature.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="bg-white rounded-lg shadow-md p-6 text-center"
            >
              <div className="w-16 h-16 bg-violet-100 rounded-full flex items-center justify-center mx-auto mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-violet-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 bg-gradient-to-r from-indigo-600 to-violet-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Become a Cyber Hero?</h2>
          <p className="text-xl mb-8">
            Start your journey to becoming cyber smart today!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/learn">
              <Button size="lg" variant="secondary" className="bg-white text-violet-700 hover:bg-gray-100">
                Start Learning
              </Button>
            </Link>
            <Link href="/games">
              <Button size="lg" className="bg-violet-800 hover:bg-violet-900 border-white border">
                Play Games
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
